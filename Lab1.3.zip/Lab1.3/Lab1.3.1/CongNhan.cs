﻿using System;

namespace LAB1._3Bai1
{
    class CongNhan : CanBo
    {
        private string? bac;

        public CongNhan() { }

        public CongNhan(string hoTen, int namSinh, string gioiTinh, string diaChi, string bac)
            : base(hoTen, namSinh, gioiTinh, diaChi)
        {
            this.bac = bac;
        }

        public override void Nhap()
        {
            base.Nhap();
            try
            {
                Console.WriteLine("Nhap bac (vi du: 3/7, 4/7): ");
                bac = Console.ReadLine();
                if (!IsValidBac(bac))
                    throw new Exception("Bac khong hop le! Phai co dang x/7 (x tu 1-7).");
            }
            catch (Exception ex)
            {
                throw new Exception("Loi nhap bac: " + ex.Message);
            }
        }

        public override void HienThi()
        {
            base.HienThi();
            Console.WriteLine($"Bac: {bac}");
        }

        private bool IsValidBac(string? bac)
        {
            if (string.IsNullOrEmpty(bac)) return false;
            string[] parts = bac.Split('/');
            if (parts.Length != 2 || parts[1] != "7") return false;
            if (int.TryParse(parts[0], out int bacSo) && bacSo >= 1 && bacSo <= 7)
                return true;
            return false;
        }
    }
}