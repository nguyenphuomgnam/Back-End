﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

public class VanBan
{
    public string NoiDung { get; set; }

    // Hàm tạo không đối
    public VanBan()
    {
        NoiDung = "";
    }

    // Hàm tạo có đối số
    public VanBan(string st)
    {
        NoiDung = st;
    }

    // Đếm số từ trong chuỗi
    public int DemSoTu()
    {
        if (string.IsNullOrWhiteSpace(NoiDung))
            return 0;

        string[] tu = NoiDung.Trim().Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        return tu.Length;
    }

    // Đếm số ký tự 'H' hoặc 'h'
    public int DemSoKyTuH()
    {
        int count = 0;
        foreach (char c in NoiDung)
        {
            if (char.ToLower(c) == 'h')
                count++;
        }
        return count;
    }

    // Chuẩn hóa chuỗi: xóa khoảng trắng dư thừa
    public string ChuanHoa()
    {
        string chuanHoa = Regex.Replace(NoiDung.Trim(), @"\s+", " ");
        return chuanHoa;
    }

    public void NhapVanBan()
    {
        Console.Write("Nhập chuỗi văn bản: ");
        NoiDung = Console.ReadLine();
    }

    public void XuatVanBan()
    {
        Console.WriteLine($"Văn bản: \"{NoiDung}\"");
    }
}
