﻿using System;

namespace LAB1._3Bai1
{
    class NhanVien : CanBo
    {
        private string? congViec;

        public NhanVien() { }

        public NhanVien(string hoTen, int namSinh, string gioiTinh, string diaChi, string congViec)
            : base(hoTen, namSinh, gioiTinh, diaChi)
        {
            this.congViec = congViec;
        }

        public override void Nhap()
        {
            base.Nhap();
            try
            {
                Console.WriteLine("Nhap cong viec: ");
                congViec = Console.ReadLine();
                if (string.IsNullOrEmpty(congViec))
                    throw new Exception("Cong viec khong duoc de trong!");
            }
            catch (Exception ex)
            {
                throw new Exception("Loi nhap cong viec: " + ex.Message);
            }
        }

        public override void HienThi()
        {
            base.HienThi();
            Console.WriteLine($"Cong viec: {congViec}");
        }
    }
}