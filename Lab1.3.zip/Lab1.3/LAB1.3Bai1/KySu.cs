﻿using System;

namespace LAB1._3Bai1
{
    class KySu : CanBo
    {
        private string? nganhDaoTao;

        public KySu() { }

        public KySu(string hoTen, int namSinh, string gioiTinh, string diaChi, string nganhDaoTao)
            : base(hoTen, namSinh, gioiTinh, diaChi)
        {
            this.nganhDaoTao = nganhDaoTao;
        }

        public override void Nhap()
        {
            base.Nhap();
            try
            {
                Console.WriteLine("Nhap nganh dao tao: ");
                nganhDaoTao = Console.ReadLine();
                if (string.IsNullOrEmpty(nganhDaoTao))
                    throw new Exception("Nganh dao tao khong duoc de trong!");
            }
            catch (Exception ex)
            {
                throw new Exception("Loi nhap nganh dao tao: " + ex.Message);
            }
        }

        public override void HienThi()
        {
            base.HienThi();
            Console.WriteLine($"Nganh dao tao: {nganhDaoTao}");
        }
    }
}