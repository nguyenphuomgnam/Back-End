﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class DaGiac
{
    public int SoCanh { get; set; }
    public int[] KichThuoc { get; set; }

    public virtual void Nhap()
    {
        Console.Write("Nhập số cạnh: ");
        SoCanh = int.Parse(Console.ReadLine());
        KichThuoc = new int[SoCanh];

        for (int i = 0; i < SoCanh; i++)
        {
            Console.Write($"Nhập cạnh thứ {i + 1}: ");
            KichThuoc[i] = int.Parse(Console.ReadLine());
        }
    }

    public virtual void HienThi()
    {
        Console.Write("Các cạnh: ");
        for (int i = 0; i < SoCanh; i++)
        {
            Console.Write(KichThuoc[i] + " ");
        }
        Console.WriteLine();
    }

    public virtual int TinhChuVi()
    {
        int chuVi = 0;
        foreach (int canh in KichThuoc)
            chuVi += canh;
        return chuVi;
    }
}

