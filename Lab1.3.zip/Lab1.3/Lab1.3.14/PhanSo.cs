﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class PhanSo
{
    public int TuSo { get; set; }
    public int MauSo { get; set; }

    public PhanSo()
    {
        TuSo = 0;
        MauSo = 1;
    }

    public PhanSo(int tu, int mau)
    {
        TuSo = tu;
        MauSo = (mau != 0) ? mau : 1;
    }

    public void Nhap()
    {
        Console.Write("Nhập tử số: ");
        TuSo = int.Parse(Console.ReadLine());

        do
        {
            Console.Write("Nhập mẫu số (khác 0): ");
            MauSo = int.Parse(Console.ReadLine());
        } while (MauSo == 0);
    }

    public void HienThi()
    {
        Console.WriteLine($"{TuSo}/{MauSo}");
    }

    public void RutGon()
    {
        int ucln = UCLN(Math.Abs(TuSo), Math.Abs(MauSo));
        TuSo /= ucln;
        MauSo /= ucln;
        if (MauSo < 0)
        {
            TuSo = -TuSo;
            MauSo = -MauSo;
        }
    }

    private int UCLN(int a, int b)
    {
        while (b != 0)
        {
            int temp = a % b;
            a = b;
            b = temp;
        }
        return a;
    }

    public PhanSo Cong(PhanSo b)
    {
        int tu = TuSo * b.MauSo + MauSo * b.TuSo;
        int mau = MauSo * b.MauSo;
        PhanSo kq = new PhanSo(tu, mau);
        kq.RutGon();
        return kq;
    }

    public PhanSo Tru(PhanSo b)
    {
        int tu = TuSo * b.MauSo - MauSo * b.TuSo;
        int mau = MauSo * b.MauSo;
        PhanSo kq = new PhanSo(tu, mau);
        kq.RutGon();
        return kq;
    }

    public PhanSo Nhan(PhanSo b)
    {
        int tu = TuSo * b.TuSo;
        int mau = MauSo * b.MauSo;
        PhanSo kq = new PhanSo(tu, mau);
        kq.RutGon();
        return kq;
    }

    public PhanSo Chia(PhanSo b)
    {
        int tu = TuSo * b.MauSo;
        int mau = MauSo * b.TuSo;
        PhanSo kq = new PhanSo(tu, mau);
        kq.RutGon();
        return kq;
    }
}


