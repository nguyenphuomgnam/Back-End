﻿using System;
using LAB1._3Bai3;

namespace LAB1._3Bai3
{
    class Program
    {
        static void Main(string[] args)
        {
            TuyenSinh tuyenSinh = new TuyenSinh();
            tuyenSinh.Menu();
        }
    }
}