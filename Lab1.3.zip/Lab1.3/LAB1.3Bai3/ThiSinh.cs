﻿using System;

namespace LAB1._3Bai3
{
    abstract class ThiSinh
    {
        protected string? soBaoDanh;
        protected string? hoTen;
        protected string? diaChi;
        protected int? uuTien;

        public ThiSinh() { }

        public ThiSinh(string soBaoDanh, string hoTen, string diaChi, int uuTien)
        {
            this.soBaoDanh = soBaoDanh;
            this.hoTen = hoTen;
            this.diaChi = diaChi;
            this.uuTien = uuTien;
        }

        public virtual void Nhap()
        {
            try
            {
                Console.WriteLine("Nhap so bao danh: ");
                soBaoDanh = Console.ReadLine();
                Console.WriteLine("Nhap ho ten: ");
                hoTen = Console.ReadLine();
                Console.WriteLine("Nhap dia chi: ");
                diaChi = Console.ReadLine();
                Console.WriteLine("Nhap muc uu tien (0-3): ");
                uuTien = int.Parse(Console.ReadLine() ?? "0");
            }
            catch (Exception ex)
            {
                throw new Exception("Loi nhap lieu: " + ex.Message);
            }
        }

        public virtual void HienThi()
        {
            Console.WriteLine($"So bao danh: {soBaoDanh}");
            Console.WriteLine($"Ho ten: {hoTen}");
            Console.WriteLine($"Dia chi: {diaChi}");
            Console.WriteLine($"Muc uu tien: {uuTien}");
        }

        public abstract double TinhTongDiem();

        public string SoBaoDanh => soBaoDanh;
    }
}