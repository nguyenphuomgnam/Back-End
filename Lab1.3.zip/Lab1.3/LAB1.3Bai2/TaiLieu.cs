﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB1._3Bai2
{
    class TaiLieu
    {
        //Khai bao
        protected string? maTL;
        protected string? tenNXB;
        protected int? soBan;
        //Phuong thuc khoi tao mac dinh

        public TaiLieu() { }
        //Phuong thuc khoi tao co tham so
        public TaiLieu(string maTL, string tenNXB, int soBan)
        {
            this.maTL = maTL;
            this.tenNXB = tenNXB;
            this.soBan = soBan;
        }
        // nhap thong tin
        public virtual void Nhap()
        {
            try
            {
                Console.WriteLine("Nhap ma tai lieu: ");
                maTL = Console.ReadLine();
                Console.WriteLine("Nhap ten nha xuat ban: ");
                tenNXB = Console.ReadLine();
                Console.WriteLine("Nhap so ban phat hanh: ");
                soBan = int.Parse(Console.ReadLine() ?? "0");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        //hien thi tai lieu
        public virtual void HienThi()
        {
            Console.WriteLine($"+ "Ma tai lieu: " + maTL);
            Console.WriteLine("Ten nha xuat ban: " + tenNXB);
            Console.WriteLine("So ban phat hanh: " + soBan);
        }
    }
}
