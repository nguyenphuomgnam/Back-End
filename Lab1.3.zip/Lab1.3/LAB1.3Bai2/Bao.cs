﻿using System;

namespace LAB1._3Bai2
{
    class Bao : TaiLieu
    {
        private string? ngayPhatHanh;

        public Bao() { }

        public Bao(string maTL, string tenNXB, int soBan, string ngayPhatHanh)
            : base(maTL, tenNXB, soBan)
        {
            this.ngayPhatHanh = ngayPhatHanh;
        }

        public override void Nhap()
        {
            try
            {
                base.Nhap();
                Console.WriteLine("Nhap ngay phat hanh (dd/mm/yyyy): ");
                ngayPhatHanh = Console.ReadLine();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public override void HienThi()
        {
            base.HienThi();
            Console.WriteLine($"Ngay phat hanh: {ngayPhatHanh}");
        }
    }
}