﻿using System;

namespace LAB1._3Bai2
{
    class TapChi : TaiLieu
    {
        private int? soPhatHanh;
        private int? thangPhatHanh;

        public TapChi() { }

        public TapChi(string maTL, string tenNXB, int soBan, int soPhatHanh, int thangPhatHanh)
            : base(maTL, tenNXB, soBan)
        {
            this.soPhatHanh = soPhatHanh;
            this.thangPhatHanh = thangPhatHanh;
        }

        public override void Nhap()
        {
            try
            {
                base.Nhap();
                Console.WriteLine("Nhap so phat hanh: ");
                soPhatHanh = int.Parse(Console.ReadLine() ?? "0");
                Console.WriteLine("Nhap thang phat hanh: ");
                thangPhatHanh = int.Parse(Console.ReadLine() ?? "0");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public override void HienThi()
        {
            base.HienThi();
            Console.WriteLine($"So phat hanh: {soPhatHanh}");
            Console.WriteLine($"Thang phat hanh: {thangPhatHanh}");
        }
    }
}