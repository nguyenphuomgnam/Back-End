﻿using System;
using System.Collections.Generic;

namespace LAB1._3Bai2
{
    class QuanLyTaiLieu
    {
        private List<TaiLieu> danhSachTaiLieu = new List<TaiLieu>();

        public void Menu()
        {
            while (true)
            {
                Console.WriteLine("\n=== QUAN LY TAI LIEU ===");
                Console.WriteLine("1. Nhap thong tin tai lieu");
                Console.WriteLine("2. Hien thi thong tin tai lieu");
                Console.WriteLine("3. Tim kiem tai lieu theo loai");
                Console.WriteLine("4. Thoat");
                Console.Write("Chon chuc nang (1-4): ");
                string? choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        NhapTaiLieu();
                        break;
                    case "2":
                        HienThiTaiLieu();
                        break;
                    case "3":
                        TimKiemTheoLoai();
                        break;
                    case "4":
                        Console.WriteLine("Thoat chuong trinh.");
                        return;
                    default:
                        Console.WriteLine("Lua chon khong hop le! Vui long chon lai.");
                        break;
                }
            }
        }

        private void NhapTaiLieu()
        {
            Console.WriteLine("\nChon loai tai lieu muon nhap:");
            Console.WriteLine("1. Sach");
            Console.WriteLine("2. Tap chi");
            Console.WriteLine("3. Bao");
            Console.Write("Nhap lua chon (1-3): ");
            string? loai = Console.ReadLine();

            TaiLieu taiLieu = null;
            switch (loai)
            {
                case "1":
                    taiLieu = new Sach();
                    break;
                case "2":
                    taiLieu = new TapChi();
                    break;
                case "3":
                    taiLieu = new Bao();
                    break;
                default:
                    Console.WriteLine("Loai tai lieu khong hop le!");
                    return;
            }

            taiLieu.Nhap();
            danhSachTaiLieu.Add(taiLieu);
            Console.WriteLine("Da them tai lieu thanh cong!");
        }

        private void HienThiTaiLieu()
        {
            if (danhSachTaiLieu.Count == 0)
            {
                Console.WriteLine("Danh sach tai lieu trong!");
                return;
            }

            Console.WriteLine("\n=== DANH SACH TAI LIEU ===");
            foreach (var taiLieu in danhSachTaiLieu)
            {
                Console.WriteLine("------------------------");
                taiLieu.HienThi();
            }
            Console.WriteLine("------------------------");
        }

        private void TimKiemTheoLoai()
        {
            Console.WriteLine("\nChon loai tai lieu muon tim:");
            Console.WriteLine("1. Sach");
            Console.WriteLine("2. Tap chi");
            Console.WriteLine("3. Bao");
            Console.Write("Nhap lua chon (1-3): ");
            string? loai = Console.ReadLine();

            Type typeToFind = null;
            switch (loai)
            {
                case "1":
                    typeToFind = typeof(Sach);
                    break;
                case "2":
                    typeToFind = typeof(TapChi);
                    break;
                case "3":
                    typeToFind = typeof(Bao);
                    break;
                default:
                    Console.WriteLine("Loai tai lieu khong hop le!");
                    return;
            }

            bool found = false;
            Console.WriteLine("\n=== KET QUA TIM KIEM ===");
            foreach (var taiLieu in danhSachTaiLieu)
            {
                if (taiLieu.GetType() == typeToFind)
                {
                    Console.WriteLine("------------------------");
                    taiLieu.HienThi();
                    found = true;
                }
            }
            if (!found)
            {
                Console.WriteLine("Khong tim thay tai lieu thuoc loai nay!");
            }
            Console.WriteLine("------------------------");
        }
    }
}