﻿using System;
using LAB1._3Bai3;

namespace LAB1._3Bai3
{
    class ThiSinhKhoiC : ThiSinh
    {
        private double? diemVan;
        private double? diemSu;
        private double? diemDia;

        public ThiSinhKhoiC() { }

        public ThiSinhKhoiC(string soBaoDanh, string hoTen, string diaChi, int uuTien,
            double diemVan, double diemSu, double diemDia)
            : base(soBaoDanh, hoTen, diaChi, uuTien)
        {
            this.diemVan = diemVan;
            this.diemSu = diemSu;
            this.diemDia = diemDia;
        }

        public override void Nhap()
        {
            base.Nhap();
            try
            {
                Console.WriteLine("Nhap diem Van: ");
                diemVan = double.Parse(Console.ReadLine() ?? "0");
                Console.WriteLine("Nhap diem Su: ");
                diemSu = double.Parse(Console.ReadLine() ?? "0");
                Console.WriteLine("Nhap diem Dia: ");
                diemDia = double.Parse(Console.ReadLine() ?? "0");
            }
            catch (Exception ex)
            {
                throw new Exception("Loi nhap diem: " + ex.Message);
            }
        }

        public override void HienThi()
        {
            base.HienThi();
            Console.WriteLine($"Diem Van: {diemVan}");
            Console.WriteLine($"Diem Su: {diemSu}");
            Console.WriteLine($"Diem Dia: {diemDia}");
            Console.WriteLine($"Tong diem: {TinhTongDiem()}");
        }

        public override double TinhTongDiem()
        {
            return (diemVan ?? 0) + (diemSu ?? 0) + (diemDia ?? 0) + (uuTien ?? 0);
        }
    }
}