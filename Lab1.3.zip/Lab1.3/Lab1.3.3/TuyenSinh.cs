﻿using System;
using System.Collections.Generic;
using LAB1._3Bai3;

namespace LAB1._3Bai3
{
    class TuyenSinh
    {
        private List<ThiSinh> danhSachThiSinh = new List<ThiSinh>();
        private const double DIEM_CHUAN_KHOI_A = 15;
        private const double DIEM_CHUAN_KHOI_B = 16;
        private const double DIEM_CHUAN_KHOI_C = 13.5;

        public void Menu()
        {
            while (true)
            {
                Console.WriteLine("\n=== QUAN LY TUYEN SINH ===");
                Console.WriteLine("1. Nhap thong tin thi sinh");
                Console.WriteLine("2. Hien thi thi sinh trung tuyen");
                Console.WriteLine("3. Tim kiem theo so bao danh");
                Console.WriteLine("4. Ket thuc chuong trinh");
                Console.Write("Chon chuc nang (1-4): ");
                string? choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        NhapThiSinh();
                        break;
                    case "2":
                        HienThiThiSinhTrungTuyen();
                        break;
                    case "3":
                        TimKiemTheoSoBaoDanh();
                        break;
                    case "4":
                        Console.WriteLine("Ket thuc chuong trinh.");
                        return;
                    default:
                        Console.WriteLine("Lua chon khong hop le! Vui long chon lai.");
                        break;
                }
            }
        }

        private void NhapThiSinh()
        {
            Console.WriteLine("\nChon khoi thi cua thi sinh:");
            Console.WriteLine("1. Khoi A");
            Console.WriteLine("2. Khoi B");
            Console.WriteLine("3. Khoi C");
            Console.Write("Nhap lua chon (1-3): ");
            string? khoi = Console.ReadLine();

            ThiSinh thiSinh = null;
            switch (khoi)
            {
                case "1":
                    thiSinh = new ThiSinhKhoiA();
                    break;
                case "2":
                    thiSinh = new ThiSinhKhoiB();
                    break;
                case "3":
                    thiSinh = new ThiSinhKhoiC();
                    break;
                default:
                    Console.WriteLine("Khoi thi khong hop le!");
                    return;
            }

            thiSinh.Nhap();
            danhSachThiSinh.Add(thiSinh);
            Console.WriteLine("Da them thi sinh thanh cong!");
        }

        private void HienThiThiSinhTrungTuyen()
        {
            if (danhSachThiSinh.Count == 0)
            {
                Console.WriteLine("Danh sach thi sinh trong!");
                return;
            }

            Console.WriteLine("\n=== DANH SACH THI SINH TRUNG TUYEN ===");
            bool found = false;
            foreach (var thiSinh in danhSachThiSinh)
            {
                double tongDiem = thiSinh.TinhTongDiem();
                bool trungTuyen = false;

                if (thiSinh is ThiSinhKhoiA && tongDiem >= DIEM_CHUAN_KHOI_A)
                    trungTuyen = true;
                else if (thiSinh is ThiSinhKhoiB && tongDiem >= DIEM_CHUAN_KHOI_B)
                    trungTuyen = true;
                else if (thiSinh is ThiSinhKhoiC && tongDiem >= DIEM_CHUAN_KHOI_C)
                    trungTuyen = true;

                if (trungTuyen)
                {
                    Console.WriteLine("------------------------");
                    thiSinh.HienThi();
                    found = true;
                }
            }
            if (!found)
            {
                Console.WriteLine("Khong co thi sinh nao trung tuyen!");
            }
            Console.WriteLine("------------------------");
        }

        private void TimKiemTheoSoBaoDanh()
        {
            Console.Write("\nNhap so bao danh can tim: ");
            string? sbd = Console.ReadLine();

            bool found = false;
            Console.WriteLine("\n=== KET QUA TIM KIEM ===");
            foreach (var thiSinh in danhSachThiSinh)
            {
                if (thiSinh.SoBaoDanh == sbd)
                {
                    Console.WriteLine("------------------------");
                    thiSinh.HienThi();
                    found = true;
                    break;
                }
            }
            if (!found)
            {
                Console.WriteLine("Khong tim thay thi sinh voi so bao danh nay!");
            }
            Console.WriteLine("------------------------");
        }
    }
}