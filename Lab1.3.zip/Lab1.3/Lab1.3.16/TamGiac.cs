﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class TamGiac
{
    public Diem D1 { get; set; }
    public Diem D2 { get; set; }
    public Diem D3 { get; set; }

    public TamGiac()
    {
        D1 = new Diem();
        D2 = new Diem();
        D3 = new Diem();
    }

    public TamGiac(Diem d1, Diem d2, Diem d3)
    {
        D1 = d1;
        D2 = d2;
        D3 = d3;
    }

    public void Nhap()
    {
        Console.WriteLine("Nhập điểm thứ nhất:");
        D1.Nhap();
        Console.WriteLine("Nhập điểm thứ hai:");
        D2.Nhap();
        Console.WriteLine("Nhập điểm thứ ba:");
        D3.Nhap();
    }

    public void HienThi()
    {
        Console.Write("Tam giác với các điểm: ");
        D1.HienThi(); Console.Write(" - ");
        D2.HienThi(); Console.Write(" - ");
        D3.HienThi(); Console.WriteLine();
    }

    public double TinhChuVi()
    {
        return D1.TinhKhoangCach(D2) + D2.TinhKhoangCach(D3) + D3.TinhKhoangCach(D1);
    }

    public double TinhDienTich()
    {
        double a = D1.TinhKhoangCach(D2);
        double b = D2.TinhKhoangCach(D3);
        double c = D3.TinhKhoangCach(D1);
        double p = (a + b + c) / 2;
        return Math.Sqrt(p * (p - a) * (p - b) * (p - c)); // Công thức Heron
    }
}
