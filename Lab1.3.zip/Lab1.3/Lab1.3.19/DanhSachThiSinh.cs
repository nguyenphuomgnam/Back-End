﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class DanhSachThiSinh
{
    private List<ThiSinh> ds = new List<ThiSinh>();

    public void NhapDanhSach(int n)
    {
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\n--- Nhập thông tin thí sinh thứ {i + 1} ---");
            ThiSinh ts = new ThiSinh();
            ts.Nhap();
            ds.Add(ts);
        }
    }

    public void HienThiDanhSach()
    {
        Console.WriteLine("\n--- Danh sách thí sinh ---");
        Console.WriteLine($"{"Họ tên",-25} | {"Quê quán",-30} | {"SBD",-10} | {"Toán",-5} | {"Lý",-5} | {"Hóa",-5} | {"Tổng",-5}");
        foreach (var ts in ds)
        {
            ts.HienThi();
        }
    }

    public void TimThiSinhDiemLonHon15()
    {
        var ketQua = ds.Where(ts => ts.DiemThi.TongDiem > 15).ToList();
        if (ketQua.Count == 0)
        {
            Console.WriteLine("Không có thí sinh nào có tổng điểm > 15.");
            return;
        }

        Console.WriteLine("\n--- Các thí sinh có tổng điểm > 15 ---");
        Console.WriteLine($"{"Họ tên",-25} | {"Quê quán",-30} | {"SBD",-10} | {"Toán",-5} | {"Lý",-5} | {"Hóa",-5} | {"Tổng",-5}");
        foreach (var ts in ketQua)
        {
            ts.HienThi();
        }
    }

    public void SapXepTheoTongDiemGiamDan()
    {
        ds = ds.OrderByDescending(ts => ts.DiemThi.TongDiem).ToList();
        Console.WriteLine("\n--- Danh sách sau khi sắp xếp giảm dần theo tổng điểm ---");
        HienThiDanhSach();
    }
}

