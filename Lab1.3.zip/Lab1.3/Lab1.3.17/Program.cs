﻿using System;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        QuanLyHinhTron ql = new QuanLyHinhTron();
        int chon;

        do
        {
            Console.WriteLine("\n=== MENU ===");
            Console.WriteLine("1. Nhập danh sách hình tròn");
            Console.WriteLine("2. Hiển thị danh sách hình tròn");
            Console.WriteLine("3. Tìm hình tròn giao nhiều hình tròn nhất");
            Console.WriteLine("0. Thoát");
            Console.Write("Chọn: ");
            chon = int.Parse(Console.ReadLine());

            switch (chon)
            {
                case 1:
                    ql.NhapDanhSach();
                    break;
                case 2:
                    ql.HienDanhSach();
                    break;
                case 3:
                    ql.TimHinhTronGiaoNhieuNhat();
                    break;
                case 0:
                    Console.WriteLine("Kết thúc chương trình.");
                    break;
                default:
                    Console.WriteLine("Lựa chọn không hợp lệ!");
                    break;
            }
        } while (chon != 0);
    }
}
