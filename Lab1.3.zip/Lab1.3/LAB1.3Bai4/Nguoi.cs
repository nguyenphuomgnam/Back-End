﻿using System;

namespace LAB1._3Bai4
{
    class Nguoi
    {
        private string? soCMND;
        private string? hoTen;
        private int? tuoi;
        private int? namSinh;
        private string? ngheNghiep;

        public Nguoi() { }

        public Nguoi(string soCMND, string hoTen, int tuoi, int namSinh, string ngheNghiep)
        {
            this.soCMND = soCMND;
            this.hoTen = hoTen;
            this.tuoi = tuoi;
            this.namSinh = namSinh;
            this.ngheNghiep = ngheNghiep;
        }

        public void Nhap()
        {
            try
            {
                Console.WriteLine("Nhap so CMND: ");
                soCMND = Console.ReadLine();
                Console.WriteLine("Nhap ho ten: ");
                hoTen = Console.ReadLine();
                Console.WriteLine("Nhap tuoi: ");
                tuoi = int.Parse(Console.ReadLine() ?? "0");
                Console.WriteLine("Nhap nam sinh: ");
                namSinh = int.Parse(Console.ReadLine() ?? "0");
                Console.WriteLine("Nhap nghe nghiep: ");
                ngheNghiep = Console.ReadLine();
            }
            catch (Exception ex)
            {
                throw new Exception("Loi nhap lieu: " + ex.Message);
            }
        }

        public void HienThi()
        {
            Console.WriteLine($"So CMND: {soCMND}");
            Console.WriteLine($"Ho ten: {hoTen}");
            Console.WriteLine($"Tuoi: {tuoi}");
            Console.WriteLine($"Nam sinh: {namSinh}");
            Console.WriteLine($"Nghe nghiep: {ngheNghiep}");
        }

        public string HoTen => hoTen;
    }
}