﻿// Bài 1: Viết chương trình nhập vào tên và tuổi, sau đó in ra màn hình thông báo
//  "Xin chào[tên], bạn[tuổi] tuổi!".
Console.OutputEncoding = System.Text.Encoding.UTF8;
//string? ten;
//int tuoi;
////nhập dữ liệu từ bàn phím
//Console.Write("Nhập tên: ");
//ten = Console.ReadLine();
//Console.Write("Nhập tuổi: ");
//tuoi = int.Parse(Console.ReadLine() ?? "0");
////xuất ra màn hình
//Console.WriteLine($"Xin chào {ten}, bạn {tuoi} tuổi");

//Bài 2: Viết chương trình tính diện tích của hình chữ nhật khi người dùng nhập chiều dài và
//chiều rộng.
//double chieudai, chieurong, dientich;
//try
//{
//    //Nhập dữ liệu
//    Console.Write("Nhập chiều dài: ");
//    chieudai = double.Parse(Console.ReadLine() ?? "0");
//    Console.Write("Nhập chiều rộng: ");
//    chieurong = double.Parse(Console.ReadLine() ?? "0");
//    if (chieudai <= 0 || chieurong <= 0)
//        throw new Exception("Dữ liệu phải lớn hơn 0");
//    //tính diện tích
//    dientich = chieudai * chieurong;
//    Console.Write($"Diện tích: {dientich}");
//}
//catch (FormatException ex)
//{
//    Console.WriteLine("loi: "+ex.Message);
//}
//catch (Exception ex)
//{
//    Console.WriteLine("loi: "+ex.Message);
//}

// Bài 3: Viết chương trình chuyển đổi nhiệt độ từ độ C sang độ F
//Công thức: F = (C * 9 / 5) + 32
//double DoC, DoF;
//try
//{
//	Console.Write("Nhập độ C: ");
//	DoC = double.Parse(Console.ReadLine() ?? "0");
//	DoF = (DoC * 9 / 5) + 32;
//	Console.WriteLine($"Độ F: {DoF}");
//}
//catch (Exception ex)
//{
//	Console.WriteLine("Loi: "+ex.Message);
//}
//Console.ReadKey();

// Bài 4: Viết chương trình nhập vào một số nguyên và kiểm tra xem số đó có phải là số chẵn
//hay không.
//try
//{
//    Console.Write("Nhập một số nguyên: ");
//    int so = int.Parse(Console.ReadLine() ?? "0");
//    if (so % 2 == 0)
//        Console.WriteLine($"{so} là số chẵn.");
//    else
//        Console.WriteLine($"{so} là số lẻ.");
//}
//catch (Exception ex)
//{
//    Console.WriteLine("Lỗi: " + ex.Message);
//}
//Console.ReadKey();

// Bài 5: Viết chương trình tính tổng và tích của hai số nhập từ bàn phím.
//try
//{
//    Console.Write("Nhập số thứ nhất: ");
//    double so1 = double.Parse(Console.ReadLine() ?? "0");
//    Console.Write("Nhập số thứ hai: ");
//    double so2 = double.Parse(Console.ReadLine() ?? "0");
//    double tong = so1 + so2;
//    double tich = so1 * so2;
//    Console.WriteLine($"Tổng: {tong}");
//    Console.WriteLine($"Tích: {tich}");
//}
//catch (Exception ex)
//{
//    Console.WriteLine("Lỗi: " + ex.Message);
//}
//Console.ReadKey();

// Bài 6: Viết chương trình kiểm tra xem một số nhập vào có phải là số dương, số âm hay số không.
//try
//{
//    Console.Write("Nhập một số: ");
//    double so = double.Parse(Console.ReadLine() ?? "0");
//    if (so > 0)
//        Console.WriteLine($"{so} là số dương.");
//    else if (so < 0)
//        Console.WriteLine($"{so} là số âm.");
//    else
//        Console.WriteLine($"{so} là số không.");
//}
//catch (Exception ex)
//{
//    Console.WriteLine("Lỗi: " + ex.Message);
//}
//Console.ReadKey();

// Bài 7: Viết chương trình kiểm tra xem một năm nhập vào có phải là năm nhuận hay không.
// (Năm nhuận là năm chia hết cho 4, trừ các năm chia hết cho 100 nhưng không chia hết cho 400).
//try
//{
//    Console.Write("Nhập một năm: ");
//    int nam = int.Parse(Console.ReadLine() ?? "0");
//    if (nam % 4 == 0)
//        if (nam % 100 == 0 && nam % 400 != 0)
//            Console.WriteLine($"{nam} không phải là năm nhuận.");
//        else
//            Console.WriteLine($"{nam} là năm nhuận.");
//    else
//        Console.WriteLine($"{nam} không phải là năm nhuận.");
//}
//catch (Exception ex)
//{
//    Console.WriteLine("Lỗi: " + ex.Message);
//}
//Console.ReadKey();

// Bài 8: Viết chương trình in ra bảng cửu chương từ 1 đến 10.
//for (int i = 1; i <= 10; i++)
//{
//    Console.WriteLine($"\nBảng cửu chương {i}:");
//    for (int j = 1; j <= 10; j++)
//    {
//        Console.WriteLine($"{i} x {j} = {i * j}");
//    }
//}
//Console.ReadKey();

// Bài 9: Viết chương trình tính giai thừa của một số nguyên dương n
//try
//{
//    Console.Write("Nhập số nguyên dương n: ");
//    int n = int.Parse(Console.ReadLine() ?? "0");
//    if (n <= 0)
//        throw new Exception("Số phải là nguyên dương!");
//    long giaithua = 1;
//    for (int i = 1; i <= n; i++)
//    {
//        giaithua *= i;
//    }
//    Console.WriteLine($"Giai thừa của {n} là: {giaithua}");
//}
//catch (Exception ex)
//{
//    Console.WriteLine("Lỗi: " + ex.Message);
//}
//Console.ReadKey();

// Bài 10: Viết chương trình kiểm tra xem một số có phải là số nguyên tố hay không.
try
{
    Console.Write("Nhập một số nguyên: ");
    int n = int.Parse(Console.ReadLine() ?? "0");
    if (n < 2)
    {
        Console.WriteLine($"{n} không phải là số nguyên tố.");
    }
    else
    {
        bool laNguyenTo = true;
        for (int i = 2; i <= Math.Sqrt(n); i++)
        {
            if (n % i == 0)
            {
                laNguyenTo = false;
                break;
            }
        }
        if (laNguyenTo)
            Console.WriteLine($"{n} là số nguyên tố.");
        else
            Console.WriteLine($"{n} không phải là số nguyên tố.");
    }
}
catch (Exception ex)
{
    Console.WriteLine("Lỗi: " + ex.Message);
}
Console.ReadKey();

